const $=s=>document.querySelector(s),E=s=>String(s==null?"":s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
let ses=null,data=null,src="all",q=new URLSearchParams(location.search).get("q")||"";
const tw=s=>{const t=document.createElement("div");$("#toast").textContent=s;$("#toast").classList.add("on");clearTimeout(tw.t);tw.t=setTimeout(()=>$("#toast").classList.remove("on"),1400)};
async function copy(t){try{await navigator.clipboard.writeText(t)}catch(e){const a=document.createElement("textarea");a.value=t;document.body.appendChild(a);a.select();document.execCommand("copy");a.remove()}tw("Copied: "+t)}
function hl(s){let h=E(s);String(q).trim().split(/\s+/).filter(Boolean).forEach(w=>{h=h.replace(new RegExp("("+E(w).replace(/[.*+?^${}()|[\]\\]/g,"\\$&")+")","gi"),"<mark>$1</mark>")});return h}
function snip(x){x=String(x||"").replace(/\s+/g," ");const w=String(q).trim().split(/\s+/)[0]||"",i=w?x.toLowerCase().indexOf(w.toLowerCase()):0,s=Math.max(0,i-40);return(s?"… ":"")+x.slice(s,s+150)+(x.length>s+150?" …":"")}
function card(r){const v=r.v;if(r.k==="c")return`<div class="cd" data-cp="${E(v.c)}"><div class="l"><b dir="auto">${hl(v.n)}</b><small dir="auto">${E(v.g)}</small>${v.d?`<p dir="auto">${hl(snip(v.d))}</p>`:""}</div><button class="cp"><code>${E(v.c)}</code><span>Copy</span></button></div>`;
 return`<div class="cd" data-op="aref"><div class="l"><small dir="auto">${E(v.l?v.l+" › ":"")}${E(v.f)}</small><b dir="auto">${hl(v.t)}</b><p dir="auto">${hl(snip(v.x))}</p></div><span class="tag">3aref</span></div>`}
function draw(){const b=$("#res");if(!b)return;if(!data){b.innerHTML='<div class="em">Loading data...</div>';return}
 if(!q.trim()){b.innerHTML=`<div class="em">Type a word to find its short code.<br><small>${data.codes.length} codes · ${data.aref.length} items</small></div>`;return}
 const r=search(data,q,src,ses.role==="admin");b.innerHTML=r.length?r.map(card).join(""):'<div class="em">No results.</div>'}
function render(){const a=$("#app");
 if(!ses){a.innerHTML=`<form class="lg" id="lf"><img src="icon128.png" alt=""><h2>3aref & Short Codes</h2><p>Sign in with your account</p><input id="u" placeholder="Username" autocapitalize="none" autocomplete="username"><input id="p" type="password" placeholder="Password" autocomplete="current-password"><div class="er" id="er"></div><button class="btn" id="go">Login</button></form>`;
  $("#lf").onsubmit=async e=>{e.preventDefault();const er=$("#er");er.textContent="";$("#go").disabled=true;try{const r=await signIn($("#u").value,$("#p").value);if(r.err){er.textContent=r.err;return}ses=r.ses;await chrome.storage.local.set({ses});render();sync()}catch(x){er.textContent="Could not verify. Check your connection."}finally{const g=$("#go");if(g)g.disabled=false}};return}
 a.innerHTML=`<div class="hd"><img src="icon48.png" alt=""><div><b>3aref & Short Codes</b><small>${E(ses.name)}</small></div><span class="sp"></span><button class="ib" id="rf" title="Refresh data">↻</button><button class="ib" id="lo">Logout</button></div><div class="bd"><input class="sr" id="q" placeholder="Search a word to get its short code..." value="${E(q)}" autocomplete="off"><div class="tb">${[["all","All"],["c","Short Codes"],["a","3aref"]].map(t=>`<button data-s="${t[0]}" class="${src===t[0]?"on":""}">${t[1]}</button>`).join("")}</div><div id="res"></div></div><div class="ft"><span id="st"></span><span><a href="${SITES.sc}" target="_blank">Short Codes site</a><a href="${SITES.aref}" target="_blank">3aref site</a></span></div>`;
 $("#q").oninput=e=>{q=e.target.value;draw()};$("#q").onkeydown=e=>{if(e.key==="Enter"&&q.trim()){const r=search(data,q,src,ses.role==="admin").find(x=>x.k==="c");if(r)copy(r.v.c)}};
 $("#rf").onclick=()=>sync(true);$("#lo").onclick=async()=>{ses=null;await chrome.storage.local.remove("ses");render()};
 document.querySelectorAll(".tb button").forEach(b=>b.onclick=()=>{src=b.dataset.s;document.querySelectorAll(".tb button").forEach(x=>x.classList.toggle("on",x===b));draw()});
 $("#res").onclick=e=>{const c=e.target.closest("[data-cp]"),o=e.target.closest("[data-op]");if(c)copy(c.dataset.cp);else if(o)chrome.tabs.create({url:SITES.aref})};
 $("#q").focus();draw()}
async function sync(m){const st=t=>{if($("#st"))$("#st").textContent=t};st("Updating...");
 try{const d=await fetchAll();data=d;try{await chrome.storage.local.set({cache:d})}catch(e){}
  const e=d.err||{},bad=Object.keys(e).map(k=>(k==="main"?"Short Codes":"3aref")+" unavailable ("+e[k]+")");
  st(bad.length?bad.join(" · "):"Updated "+new Date().toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"}))}
 catch(e){st((data?"Offline - saved data · ":"Could not load: ")+(e&&e.message||e))}draw()}
(async()=>{const st=await chrome.storage.local.get(["ses","cache"]);ses=st.ses||null;data=st.cache||null;render();if(ses)sync()})();
