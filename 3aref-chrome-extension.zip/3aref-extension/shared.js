const FB={apiKey:"AIzaSyD0hXeaWNI52YRv-Qr56-hg6ojL-AuKmwc",projectId:"shortcodes-ac9ae"};
const DOCS="https://firestore.googleapis.com/v1/projects/"+FB.projectId+"/databases/(default)/documents/shortcodes/";
const SITES={sc:"https://scodes-et.github.io/SS/",aref:"https://scodes-et.github.io/SS/3aref/"};
const nrm=s=>String(s||"").toLowerCase().replace(/[\u064B-\u065F\u0670\u0640]/g,"").replace(/[أإآٱ]/g,"ا").replace(/ى/g,"ي").replace(/ة/g,"ه").replace(/\s+/g," ").trim();
async function gdoc(n){const r=await fetch(DOCS+n+"?key="+FB.apiKey,{cache:"no-store"});if(r.status===404)return{};if(!r.ok)throw new Error(n+" "+r.status);return(await r.json()).fields||{}}
const pj=f=>{try{return JSON.parse(f.json.stringValue)}catch(e){return null}};
async function fetchAll(){
 const [m,a]=await Promise.all([gdoc("main"),gdoc("aref")]),M=pj(m)||{},A=pj(a)||{},codes=[],aref=[];
 (M.categories||[]).forEach(c=>(c.codes||[]).forEach(k=>codes.push({n:String(k.name||""),c:String(k.shortCode==null?"":k.shortCode),d:String(k.description||""),g:String(c.name||"")})));
 const topics=A.topics||[],lists=A.lists||[],lname=new Map();
 lists.forEach(l=>(l.folders||[]).forEach(e=>{if(e.ref&&!lname.has(e.ref))lname.set(e.ref,l.name)}));
 const add=(f,l,v)=>(f.blocks||[]).forEach(b=>aref.push({f:String(f.name||""),l:l||"",v:v,t:String(b.title||""),x:String(b.body||"").replace(/\t/g," | ")}));
 topics.forEach(f=>add(f,lname.get(f.id),lname.has(f.id)));
 lists.forEach(l=>(l.folders||[]).forEach(e=>{if(!e.ref)add(e,l.name,true)}));
 return{ts:Date.now(),codes:codes,aref:aref}}
function search(d,q,src,admin){const t=nrm(q).split(" ").filter(Boolean);if(!t.length||!d)return[];const out=[];
 if(src!=="a")for(const k of d.codes){const n=nrm(k.n),c=nrm(k.c);if(!t.every(w=>(n+" "+c+" "+nrm(k.d)+" "+nrm(k.g)).includes(w)))continue;let s=0;t.forEach(w=>{if(c===w)s+=50;else if(c.startsWith(w))s+=25;if(n.startsWith(w))s+=20;else if(n.includes(w))s+=10;else s+=2});out.push({k:"c",s:s,v:k})}
 if(src!=="c")for(const b of d.aref){if(!admin&&!b.v)continue;const ti=nrm(b.t),fo=nrm(b.f);if(!t.every(w=>(ti+" "+nrm(b.x)+" "+fo).includes(w)))continue;let s=0;t.forEach(w=>{s+=ti.includes(w)?10:fo.includes(w)?6:2});out.push({k:"a",s:s-1,v:b})}
 return out.sort((a,b)=>b.s-a.s).slice(0,40)}
/* ---- login (same accounts as the sites) ---- */
const hex=b=>[...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,"0")).join("");
async function H(salt,pw){const en=new TextEncoder(),k=await crypto.subtle.importKey("raw",en.encode(String(pw)),"PBKDF2",false,["deriveBits"]);return hex(await crypto.subtle.deriveBits({name:"PBKDF2",hash:"SHA-256",salt:en.encode(String(salt)),iterations:100000},k,256))}
async function siteUsers(){const [u,p]=await Promise.all([gdoc("users"),gdoc("phones")]);const L=(pj(u)||{}).users||[],m=(p.map&&p.map.mapValue&&p.map.mapValue.fields)||{};
 return L.map(x=>{if(!(x.id in m))return x;let o={};try{o=JSON.parse(m[x.id].stringValue)}catch(e){}const n={};["name","username","salt","hash"].forEach(k=>{if(typeof o[k]==="string")n[k]=o[k]});return Object.assign({},x,n)})}
async function signIn(un,pw){un=un.trim();
 if(un.includes("@")){const r=await fetch("https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key="+FB.apiKey,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({email:un,password:pw,returnSecureToken:true})});
  if(!r.ok)return{err:"Incorrect username or password."};return{ses:{role:"admin",name:"Admin"}}}
 const L=await siteUsers(),x=L.find(v=>String(v.username||"").trim().toLowerCase()===un.toLowerCase());
 if(!x||await H(x.salt,pw)!==x.hash)return{err:"Incorrect username or password."};
 if(x.status!=="active")return{err:"Your account is not active. Contact the admin."};
 return{ses:{role:"user",name:x.name}}}
