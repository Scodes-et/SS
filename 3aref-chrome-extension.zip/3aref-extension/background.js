importScripts("shared.js");
const alarm=()=>chrome.alarms.create("rf",{periodInMinutes:30});
chrome.runtime.onInstalled.addListener(()=>{alarm();chrome.contextMenus.create({id:"sc",title:'Search "%s" in Short Codes / 3aref',contexts:["selection"]});refresh()});
chrome.runtime.onStartup.addListener(()=>{alarm();refresh()});
chrome.alarms.onAlarm.addListener(a=>{if(a.name==="rf")refresh()});
async function refresh(){try{await chrome.storage.local.set({cache:await fetchAll()})}catch(e){}}
const win=q=>chrome.windows.create({url:"popup.html?q="+encodeURIComponent(q||""),type:"popup",width:440,height:640});
chrome.contextMenus.onClicked.addListener(i=>{if(i.menuItemId==="sc")win(i.selectionText)});
const X=s=>String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&apos;"}[c]));
chrome.omnibox.setDefaultSuggestion({description:"Search Short Codes and 3aref for <match>%s</match>"});
chrome.omnibox.onInputChanged.addListener(async(text,suggest)=>{const {ses,cache}=await chrome.storage.local.get(["ses","cache"]);
 if(!ses){suggest([{content:"login",description:"Open the extension and sign in first"}]);return}
 if(!cache)return;const seen=new Set(),out=[];
 for(const r of search(cache,text,"all",ses.role==="admin")){const c=r.k==="c"?r.v.n:r.v.t||r.v.f;if(seen.has(c))continue;seen.add(c);
  out.push({content:c,description:r.k==="c"?`<match>${X(r.v.n)}</match>  <url>${X(r.v.c)}</url>`:`3aref: <match>${X(r.v.f)} › ${X(r.v.t)}</match>`});if(out.length>=6)break}
 suggest(out)});
chrome.omnibox.onInputEntered.addListener(t=>win(t));
